#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
	srand(time(NULL));
	int range=21;
	int bound=(RAND_MAX+1)/range,x;
	do
	{
		x=rand();
	}
	while(x>=bound*range);
	printf("%d\n",x%range+15);
	return 0;
}
