#include<stdio.h>
int lcm(int,int);
int gcd(int,int);

int main(void)
{
	int n,m,p;
	scanf("%d%d",&n,&m);
	p=lcm(n,m);
	while(scanf("%d",&n))
		p=lcm(p,n);
	printf("%d",p);		
	return 0;
}

int gcd(int a,int b)
{
	int r;
	while(b)
		r=a%b , a=b ,b=r;
	return a;
}

int lcm(int a,int b)
{
	return (a*b/gcd(a,b));
}
